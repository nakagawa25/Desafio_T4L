﻿namespace T4LSystemLibrary.Utils
{
    public class Methods
    {

    }
}
