﻿namespace T4LSystemLibrary.VO
{
    public class ProdutoGrupoVO : StandardVO
    {
        public string Nome { get; set; }
    }
}
