﻿using System;
using System.Windows;
using System.Windows.Input;
using T4LSystemBackEnd.BusinessLayer;
using T4LSystemBackEnd.Utils;

namespace T4LSystem.Sale
{
    /// <summary>
    /// Interaction logic for SaleOperationInterface.xaml
    /// </summary>
    public partial class SaleOperationInterface : Window
    {
        private static bool InsertClientData { get; set; } = false;
        private SaleController SaleControllerObject { get; set; }
        public SaleOperationInterface()
        {
            InitializeComponent();
            StartSale();
        }
        private void StartSale()
        {
            ClearAllFields();
            btnInsertSaleProduct.IsEnabled = false;
            InsertClientData = VerifyInsertClientData();
            AllowClientNameAndDocumentInsert();
            SaleControllerObject = new SaleController();
            RefreshList();
        }
        private void ClearAllFields()
        {
            SaleControllerObject = null;
            dgdSaleList.ItemsSource = null;
            txtClientName.Clear();
            txtClientDocument.Clear();
            txtProductAmount.Clear();
            txtProductCode.Clear();
            txtObservation.Clear();
            lblTotalValue.Content = 0;
        }

        private bool VerifyInsertClientData()
        {
            return (MessageBox.Show("Deseja inserir documento e/ou nome do cliente?", "Confirmação", MessageBoxButton.YesNo) == MessageBoxResult.Yes) ? true : false;
        }

        private void AllowClientNameAndDocumentInsert()
        {
            txtClientName.IsEnabled = InsertClientData;
            txtClientDocument.IsEnabled = InsertClientData;
            lblClientName.IsEnabled = InsertClientData;
            lblClientDocument.IsEnabled = InsertClientData;
            if (InsertClientData)
                txtClientName.Focus();
            else
                txtProductCode.Focus();
        }

        private void OnKeyDownHandlerProduct(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                if (AddProduct())
                    txtProductAmount.Focus();
            }
        }

        private void OnKeyDownHandlerAmount(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
            {
                if (AddAmount())
                {
                    txtProductAmount.Clear();
                    txtProductCode.Clear();
                    txtProductCode.Focus();
                }
            }
        }

        private void RefreshList()
        {
            try
            {
                dgdSaleList.ItemsSource = null;
                dgdSaleList.ItemsSource = SaleControllerObject.SelectProductWithAmountList();
                lblTotalValue.Content = SaleControllerObject.TakeTotalSaleValue().ToString("N");
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao recarregar a lista de produtos da venda. Erro: " + error.Message);
            }
        }

        private bool AddAmount()
        {
            try
            {
                int amount = Convert.ToInt32(txtProductAmount.Text);
                if (amount <= 0)
                {
                    MessageBox.Show("A quantidade deve ser maior que 0.");
                    return false;
                }
                else
                {
                    SaleControllerObject.UpdateProductAmountInTheList(amount);
                    RefreshList();
                    btnInsertSaleProduct.IsEnabled = true;
                    return true;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao inserir a quantidade. Erro: " + error.Message);
                return false;
            }
        }

        private bool AddProduct()
        {
            try
            {
                int code = Convert.ToInt32(txtProductCode.Text);
                SelectProductByCodeStatus operationStatus = SaleControllerObject.InsertProductOnSaleList(code);
                switch (operationStatus)
                {
                    case SelectProductByCodeStatus.Success:
                        MessageBox.Show("Produto adicionado na lista da venda, digite a quantidade desse produto na venda.");
                        return true;
                    case SelectProductByCodeStatus.NotFound:
                        MessageBox.Show("O produto não foi encontrado, digite outro código.");
                        return false;
                    case SelectProductByCodeStatus.ProductDeactivated:
                        MessageBox.Show("Esse produto está desativado");
                        return false;
                    case SelectProductByCodeStatus.OperationError:
                        MessageBox.Show("Erro na operação. Consulte os Logs");
                        return false;
                    case SelectProductByCodeStatus.NeedInsertAmount:
                        MessageBox.Show("Digite a quantidade do produto antes de inserir um novo produto na venda.");
                        return false;
                    default:
                        return false;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao adicionar produto na venda. Erro: " + error.Message);
                return false;
            }
        }

        private void BtnInserSaleProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string clientDocument = InsertClientData ? txtClientDocument.Text.Trim() : string.Empty;
                string message = string.Empty;
                if (InsertClientData && CPFValidator.VerifyCPF(clientDocument) != true)
                    message = "O CPF digitado está incorreto, favor verificar e tentar novamente.";
                else
                    message = SaleControllerObject.InsertSale(txtClientName.Text.Trim(), clientDocument, txtObservation.Text.Trim()) ? "Sucesso!" : "Não foi possível inserir a venda. confira os logs";     
                MessageBox.Show(message);
                StartSale();
            }
            catch (Exception error)
            {
                MessageBox.Show("Houve um erro ao inserir a venda. Erro: " + error.Message);
            }
        }
    }
}
