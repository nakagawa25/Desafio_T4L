﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using T4LSystemLibrary.VO;
using T4LSystemBackEnd.BusinessLayer;

namespace T4LSystem.Product
{
    /// <summary>
    /// Lógica interna para CreateProdcutInterface.xaml
    /// </summary>
    public partial class CreateProdcutInterface : Window
    {
        private static bool IsUpdateOperation { get; set; } = false;
        private ProdutoVO ProductToUpdate { get; set; }

        public CreateProdcutInterface(ProdutoVO product = null)
        {
            InitializeComponent();
            LoadProductGroupComboBox();
            LoadProductFields(product);
        }

        private void LoadProductFields(ProdutoVO product)
        {
            try
            {
                if (product == null)
                    return;
                IsUpdateOperation = true;
                ProductToUpdate = product;
                txtProductDescription.Text = ProductToUpdate.Descricao;
                txtProductBarCode.Text = ProductToUpdate.CodBarra;
                txtProductPriceValue.Text = ProductToUpdate.PrecoCusto.ToString();
                txtProductMarketPriceValue.Text = ProductToUpdate.PrecoVenda.ToString();
                chbProductActive.IsChecked = ProductToUpdate.Ativo == 1;

                //TODO:
                // Arrumar essa parte
                cbProductGroup.SelectedItem = ProductToUpdate.CodGrupo;
                btnInsert.Content = "Atualizar Produto";
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao preencher os campos do produto. Erro: " + error.Message);
            }
        }

        private void LoadProductGroupComboBox()
        {
            try
            {
                cbProductGroup.ItemsSource = ProductGroupController.SelectProductGroup();
                cbProductGroup.DisplayMemberPath = "Nome";
                cbProductGroup.SelectedValuePath = "Cod";
            }
            catch (Exception error)
            {
                // TODO:
                // Grava Log
                MessageBox.Show("Erro ao carregar os grupos dos produtos, favor verificar os Logs.");
            }
        }
        private int TakeProductGroupCode()
        {
            try
            {
                return Convert.ToInt32((cbProductGroup.SelectedItem as ProdutoGrupoVO).Cod);
            }
            catch (Exception)
            {
                return 0;
            }
        }
        private void BtnInsert_Click(object sender, RoutedEventArgs e)
        {
            string productDescription = txtProductDescription.Text.Trim();
            string productBarCode = txtProductBarCode.Text.Trim();
            string productCostPrice = txtProductPriceValue.Text.Trim();
            string productMarketPrice = txtProductMarketPriceValue.Text.Trim();
            int productGroupCode = TakeProductGroupCode();
            if (productGroupCode <= 0)
            {
                MessageBox.Show("Escolha um grupo de produto.");
                return;
            }
            int productActive = (chbProductActive.IsChecked == true) ? 1 : 0;
            ProdutoVO product;
            if (IsUpdateOperation)
            {
                if (ProductController.ValidateProductInputs(productDescription, productGroupCode, productBarCode, productCostPrice, productMarketPrice, productActive, out product, ProductToUpdate.Cod))
                {
                    string message = ProductController.UpdateProduct(product) ? "Produto Atualizado com sucesso!" : "ERRO!!! Não foi possível atualizar o produto, verifique os logs para mais informações.";
                    MessageBox.Show(message);
                }
                else
                    MessageBox.Show("Os campos inseridos não estão corretos.");
                this.Close();
            }
            else
            {
                if (ProductController.ValidateProductInputs(productDescription, productGroupCode, productBarCode, productCostPrice, productMarketPrice, productActive, out product))
                {
                    string message = ProductController.InsertProduct(product) ? "Produto Cadastrado com sucesso!" : "ERRO!!! Não foi possível cadastrar o produto, verifique os logs para mais informações.";
                    MessageBox.Show(message);
                }
                else
                    MessageBox.Show("Os campos inseridos não estão corretos.");
            }
        }

    }
}
