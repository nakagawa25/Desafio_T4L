﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using T4LSystemLibrary.DAO;
using T4LSystemLibrary.VO;

namespace T4LSystemBackEnd.BusinessLayer
{
    public class ProductGroupController
    {
        public static List<ProdutoGrupoVO> SelectProductGroup()
        {
            try
            {
                ProdutoGrupoDAO productGroupDAO = new ProdutoGrupoDAO();
                return productGroupDAO.Select().Cast<ProdutoGrupoVO>().ToList();
            }
            catch (Exception error)
            {
                // TODO:
                // Gravar Log.
                return null;
            }
        }
    }
}
