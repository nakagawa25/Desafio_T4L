﻿namespace T4LSystemLibrary.VO
{
    public class ProductWithAmount
    {
        public ProdutoVO Product { get; set; }
        public int Amount { get; set; }
        public double Total { get; set; }
    }
}
