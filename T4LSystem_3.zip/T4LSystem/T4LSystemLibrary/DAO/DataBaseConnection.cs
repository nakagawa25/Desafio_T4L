﻿using MySql.Data.MySqlClient;

namespace T4LSystemLibrary.DAO
{
    internal static class DataBaseConnection
    {
        internal static MySqlConnection GetConnection()
        {
            // TODO: 
            // Armazenar Hash da senha em uma variável de ambiente ou afins...

            string stringConnection = "Persist Security Info = False;server = localhost;database = testdev;uid = lucas; pwd = lucas167";
            MySqlConnection connection = new MySqlConnection(stringConnection);
            connection.Open();
            return connection;
        }
    }
}
