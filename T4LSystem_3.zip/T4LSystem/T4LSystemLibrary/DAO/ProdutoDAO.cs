﻿using System;
using System.Collections.Generic;
using System.Data;
using MySql.Data.MySqlClient;
using T4LSystemLibrary.VO;

namespace T4LSystemLibrary.DAO
{
    public class ProdutoDAO : StandardDAO
    {
        public ProdutoDAO()
        {
            TableName = "produto";
        }

        protected override MySqlParameter[] CreateParameters(StandardVO standardVO)
        {
            ProdutoVO produto = standardVO as ProdutoVO;
            MySqlParameter[] parameters =
            {
                new MySqlParameter("cod", produto.Cod),
                new MySqlParameter("descricao", produto.Descricao),
                new MySqlParameter("codGrupo", produto.CodGrupo),
                new MySqlParameter("codBarra", produto.CodBarra),
                new MySqlParameter("precoCusto", produto.PrecoCusto),
                new MySqlParameter("precoVenda", produto.PrecoVenda),
                new MySqlParameter("ativo", produto.Ativo),
                new MySqlParameter("dataHoraCadastro", produto.DataHoraCadastro)
            };
            return parameters;
        }

        protected override string CreateInsertQuery()
        {
            return $"INSERT INTO {TableName} (descricao, codGrupo, codBarra, precoCusto, precoVenda, ativo, dataHoraCadastro) VALUES (@descricao, @codGrupo, @codBarra, @precoCusto, @precoVenda, @ativo, @dataHoraCadastro)";
        }

        protected override string CreateUpdateQuery()
        {
            return $"UPDATE {TableName} SET descricao = @descricao, codGrupo = @codGrupo, codBarra = @codBarra, precoCusto = @precoCusto, precoVenda = @precoVenda, ativo = @ativo, dataHoraCadastro = @dataHoraCadastro WHERE cod = @cod";
        }

        public ProdutoVO SelectProductByCode(int code)
        {
            string sqlCommand = $"SELECT * FROM {TableName} WHERE cod = @cod";
            MySqlParameter[] parameters = { new MySqlParameter("cod", code) };
            List<StandardVO> returnedProductList = ConvertDataTableToList(DataBaseUtils.ExecuteOnlySelectQuery(sqlCommand, parameters));
            return (returnedProductList.Count > 0) ? returnedProductList[0] as ProdutoVO : null;
        }

        protected override StandardVO CreateVO(DataRow dataRow)
        {
            ProdutoVO produto = new ProdutoVO
            {
                Cod = Convert.ToInt64(dataRow["cod"]),
                Descricao = dataRow["descricao"].ToString(),
                CodGrupo = Convert.ToInt32(dataRow["codGrupo"]),
                CodBarra = dataRow["codBarra"].ToString(),
                PrecoCusto = Convert.ToDouble(dataRow["precoCusto"]),
                PrecoVenda = Convert.ToDouble(dataRow["precoVenda"]),
                Ativo = Convert.ToInt16(dataRow["ativo"]),
                DataHoraCadastro = Convert.ToDateTime(dataRow["dataHoraCadastro"])
            };

            return produto;
        }
    }
}
