﻿using System;
using System.Windows;
using System.Windows.Input;
using T4LSystemBackEnd.BusinessLayer;
using T4LSystemBackEnd.Utils;

namespace T4LSystem.Sale
{
    /// <summary>
    /// Interaction logic for SaleOperationInterface.xaml
    /// </summary>
    public partial class SaleOperationInterface : Window
    {
        private static bool InsertClientData { get; set; } = false;
        private SaleController SaleControllerObject { get; set; }
        public SaleOperationInterface()
        {
            InitializeComponent();
            InsertClientData = VerifyInsertClientData();
            AllowClientNameAndDocumentInsert();
            SaleControllerObject = new SaleController();
            RefreshList();
        }
        private bool VerifyInsertClientData()
        {
            return (MessageBox.Show("Deseja inserir documento e/ou nome do cliente?", "Confirmação", MessageBoxButton.YesNo) == MessageBoxResult.Yes) ? true : false;
        }
        private void AllowClientNameAndDocumentInsert()
        {
            txtClientName.IsEnabled = InsertClientData;
            txtClientDocument.IsEnabled = InsertClientData;
            lblClientName.IsEnabled = InsertClientData;
            lblClientDocument.IsEnabled = InsertClientData;
        }

        private void OnKeyDownHandlerProduct(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
                AddProduct();
        }

        private void OnKeyDownHandlerAmount(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.Return)
                AddAmount();
        }


        private void RefreshList()
        {
            try
            {
                dgdSaleList.ItemsSource = null;
                dgdSaleList.ItemsSource = SaleControllerObject.SelectProductWithAmountList();
                lblTotalValue.Content = SaleControllerObject.TakeTotalSaleValue().ToString("N");
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao recarregar a lista de produtos da venda. Erro: " + error.Message);
            }
        }

        private void AddAmount()
        {
            try
            {
                int amount = Convert.ToInt32(txtProductAmount.Text);
                if (amount <= 0)
                    MessageBox.Show("A quantidade deve ser maior que 0.");
                else
                {
                    SaleControllerObject.UpdateProductAmountInTheList(amount);
                    RefreshList();
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao inserir a quantidade. Erro: " + error.Message);
                return;
            }
        }

        private void AddProduct()
        {
            try
            {
                int code = Convert.ToInt32(txtProductCode.Text);
                SelectProductByCodeStatus operationStatus = SaleControllerObject.InsertProductOnSaleList(code);
                switch (operationStatus)
                {
                    case SelectProductByCodeStatus.Success:
                        MessageBox.Show("Produto adicionado na lista da venda, digite a quantidade desse produto na venda.");
                        break;
                    case SelectProductByCodeStatus.NotFound:
                        MessageBox.Show("O produto não foi encontrado, digite outro código.");
                        break;
                    case SelectProductByCodeStatus.ProductDeactivated:
                        MessageBox.Show("Esse produto está desativado");
                        break;
                    case SelectProductByCodeStatus.OperationError:
                        MessageBox.Show("Erro na operação. Consulte os Logs");
                        break;
                    case SelectProductByCodeStatus.NeedInsertAmount:
                        MessageBox.Show("Digite a quantidade do produto antes de inserir um novo produto na venda.");
                        break;
                }
            }
            catch (Exception error)
            {
                MessageBox.Show("Erro ao adicionar produto na venda. Erro: " + error.Message);
            }
        }

        private void BtnInserSaleProduct_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string clientDocument = txtClientDocument.Text.Trim();
                string message = string.Empty;
                if (CPFValidator.VerifyCPF(clientDocument) != true)
                    message = "O CPF digitado está incorreto, favor verificar e tentar novamente.";
                else
                    message = SaleControllerObject.InsertSale(txtClientName.Text.Trim(), clientDocument) ? "Sucesso!" : "Não foi possível inserir a venda. confira os logs";     
                MessageBox.Show(message);
            }
            catch (Exception error)
            {
                MessageBox.Show("Houve um erro ao inserir a venda. Erro: " + error.Message);
            }
        }
    }
}
