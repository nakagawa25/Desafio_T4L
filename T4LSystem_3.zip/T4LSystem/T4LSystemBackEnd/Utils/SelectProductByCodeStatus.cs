﻿namespace T4LSystemBackEnd.Utils
{
    public enum SelectProductByCodeStatus
    {
        Success, NotFound, ProductDeactivated, NeedInsertAmount, OperationError
    }
}
