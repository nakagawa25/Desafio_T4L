﻿namespace T4LSystemLibrary.VO
{
    public abstract class StandardVO
    {
        public virtual long Cod { get; set; }
    }
}
