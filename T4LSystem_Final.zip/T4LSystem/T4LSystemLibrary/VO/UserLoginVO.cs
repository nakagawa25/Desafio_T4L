﻿namespace T4LSystemLibrary.VO
{
    public class UserLoginVO : StandardVO
    {
        public string Credential { get; set; }
        public string Password { get; set; }
    }
}
