﻿namespace T4LSystemLibrary.VO
{
    public class MedidaVO : StandardVO
    {
        public string UnidadeMedida { get; set; }
    }
}
