﻿namespace T4LSystemLibrary.VO
{
    public class ProductWithAmount
    {
        public ProdutoVO Product { get; set; }
        public double Amount { get; set; }
        public double Total { get; set; }
    }
}
